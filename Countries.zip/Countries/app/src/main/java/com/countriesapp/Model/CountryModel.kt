package com.countriesapp.Model

class CountryModel(val alpha3Code : String, val name : String, val nativeName : String, val area : String, val borders : ArrayList<String> ) {

    override fun toString(): String {
        return "CountryModel(alpha3Code='$alpha3Code', name='$name', nativeName='$nativeName', area='$area', borders=$borders)"
    }
}