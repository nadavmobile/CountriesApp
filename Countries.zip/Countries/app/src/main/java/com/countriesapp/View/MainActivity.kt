package com.countriesapp.View

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.recyclerview.widget.LinearLayoutManager
import com.countriesapp.Adapter.CountryViewAdapter
import com.countriesapp.Data.CountriesMap
import com.countriesapp.Model.CountryModel
import com.countriesapp.R
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    var list = arrayListOf<CountryModel>()
    var sortFlag = "none"
    var sortDirectionFlag = "down"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        list = mapToArrayList(CountriesMap.map)  // convert the static hash Map to array list

        main_rcv.layoutManager = LinearLayoutManager(this)  // set manger of the list
        val adapter = CountryViewAdapter(this) // set the list adapter
        main_rcv.adapter = adapter // bind the adapter
        adapter.setData(list) // bind the list to the adapter

        setSort(adapter) // function set all the functions of the sort
    }

    private fun setSort(adapter: CountryViewAdapter) {

        val sortItem = listOf("", "name", "area")  // set list of sort type to the drop down list (Spinner)
        val sortAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, sortItem) // set the drop down list adapter and bind the list to the adapter
        sort_spi.adapter = sortAdapter // bind the adapter

        sort_spi.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {  // set listener that  defines all the functions of the sort
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {

                when (p2) {
                    0 -> {
                        sortFlag = "none"   // set the type of sort flag
                        adapter.setData(list)  // bind the default list to the adapter
                        sort_img.visibility = View.INVISIBLE // set visibility of direction sort button to INVISIBLE
                        sort_img.isClickable = false  // set direction sort button to not clickable
                    }
                    1 -> {
                        sortFlag = "name"
                        sortDirectionFlag = "down" // set the sort direction flag to default
                        if (list.isNotEmpty()) {
                            val newList = list.sortedBy { it.name }  // sort the list by name
                            adapter.setData(newList)
                        }
                        sort_img.setImageResource(R.drawable.ic_arrow_downward) // set direction sort button image to default (down)
                        sort_img.visibility = View.VISIBLE // set visibility of direction sort button to VISIBLE
                        sort_img.isClickable = true  // set direction sort button to clickable
                    }
                    2 -> {
                        sortFlag = "area"
                        sortDirectionFlag = "down" // set the sort direction flag to default
                        if (list.isNotEmpty()) {
                            val newList = list.sortedBy { it.area } // sort the list by area
                            adapter.setData(newList)
                        }
                        sort_img.setImageResource(R.drawable.ic_arrow_downward)
                        sort_img.visibility = View.VISIBLE
                        sort_img.isClickable = true
                    }
                }
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {}
        }

        sort_img.setOnClickListener {

            val reverseList  = adapter.asyncListDiffer.currentList  // get the current list

            if(reverseList.isNotEmpty()){
                adapter.setData(reverseList.reversed()) // set the list reversed
            }
            if (sortDirectionFlag == "down"){

                sortDirectionFlag = "up"
                sort_img.setImageResource(R.drawable.ic_arrow_upward)
            }else{
                sortDirectionFlag = "down"
                sort_img.setImageResource(R.drawable.ic_arrow_downward)
            }
        }
    }

    private fun mapToArrayList(map: HashMap<String, CountryModel>): ArrayList<CountryModel> {

        val returnArrayLInst = arrayListOf<CountryModel>()

        if (map.isNotEmpty()) {

            map.forEach {
                returnArrayLInst.add(it.value)
            }
        }

        return returnArrayLInst

    }
}