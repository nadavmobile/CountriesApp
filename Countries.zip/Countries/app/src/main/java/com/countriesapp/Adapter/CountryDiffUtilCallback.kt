package com.countriesapp.Adapter

import androidx.recyclerview.widget.DiffUtil
import com.countriesapp.Model.CountryModel


class CountryDiffUtilCallback : DiffUtil.ItemCallback<CountryModel>() {
    override fun areItemsTheSame(oldItem: CountryModel, newItem: CountryModel): Boolean {

        return oldItem.hashCode() == newItem.hashCode()

    }

    override fun areContentsTheSame(oldItem: CountryModel, newItem: CountryModel): Boolean {

        return oldItem.alpha3Code == newItem.alpha3Code
//        return true
    }
}