package com.countriesapp.Data

import com.countriesapp.Model.CountryModel


class CountriesMap {

    companion object {

        private var bordersMap = hashMapOf<String,CountryModel>();

        val map: HashMap<String,CountryModel>
            get() {
                return bordersMap
            }



    }

}