package com.countriesapp.View

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.countriesapp.Data.CountriesMap
import com.countriesapp.Model.CountryModel
import com.countriesapp.R
import kotlinx.android.synthetic.main.activity_country.*

class CountryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_country)

        val mainCountryAlpha3Code = intent.getStringExtra("alpha3Code") // get Alpha3Cod of the selected country
        val mainCountry = CountriesMap.map[mainCountryAlpha3Code]!! // load the selected country

        val text_country_name = mainCountry.name + ", " + mainCountry.nativeName // get name and native name
        country_name_txt.text = text_country_name  // set name and native name to the textView

        bordering_countries_txt.text = getBborders(mainCountry)  // function get the borders countries of the selected country
    }

    private fun getBborders(mainCountry: CountryModel): String {

        var text_borders = ""

        if (mainCountry.borders.isNotEmpty()) { // if selected country has borders countries
            mainCountry.borders.forEach {  // for each border Alpha3Cod, it - Alpha3Cod
                val text_border = CountriesMap.map[it]!!.name + ", " + CountriesMap.map[it]!!.nativeName + "\n"  // get from the static hash Map the border country name and native name
                text_borders += text_border // add the border country name and native name
            }
        } else { // if selected country hasn't borders countries
            text_borders = "none"  // add "none" tag
        }

        return text_borders
    }
}