package com.countriesapp.View

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.lifecycleScope
import com.countriesapp.Data.CountriesMap
import com.countriesapp.Model.CountryModel
import com.countriesapp.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import java.net.URL

class StartActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start)

        // coroutine lifecycleScope
        lifecycleScope.launch(Dispatchers.Main) {
            getData()   // function get data from url
        }

    }

    private suspend fun getData() {

        var data = ""

        // coroutine scope
        withContext(Dispatchers.IO) {
            try {

                data =
                        URL(getString(R.string.url)).readText() // HTTP request, return data to string

            } catch (e: Exception) {

                Log.e("HTTP request", e.stackTraceToString())
            }

        }

        setData(data)       // covert data to JSON format and add it to data model
    }

    private fun setData(data: String) {
        try {

            val jsonArrayData = JSONArray(data)  // covert data to JSON Array

            for (i in 0 until jsonArrayData.length()) {  // scan the JSON Array and add it to model structure

                val jsonObject = jsonArrayData.getJSONObject(i) // get JSON object by index i from the JSON Array
                // convert the data from the JSON object by keys
                val alpha3Code = jsonObject.getString("alpha3Code")
                val name = jsonObject.getString("name")
                val nativeName = jsonObject.getString("nativeName")
                val area = jsonObject.getString("area")
                // function get all the borders from internal JSON Array and return String Array
                val borders = getBorders(jsonObject.getJSONArray("borders"))
                // add data to model and add it to static hashMap (structure)
                CountriesMap.map[alpha3Code] = CountryModel(alpha3Code, name, nativeName, area, borders)

                Log.e("testSetData", CountriesMap.map[alpha3Code].toString())

            }

        } catch (e: JSONException) {

            Log.e("JSONException", e.stackTraceToString())
        }

        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun getBorders(jsonArray: JSONArray): ArrayList<String> {

        val returnedList = arrayListOf<String>()

        for (i in 0 until jsonArray.length()) {  // scan the JSON Array and add it to model structure
            returnedList.add(jsonArray.getString(i)) // get String by index i from the internal JSON Array
        }

        return returnedList
    }

}