package com.countriesapp.Adapter

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.RecyclerView
import com.countriesapp.Model.CountryModel
import com.countriesapp.R
import com.countriesapp.View.CountryActivity
import kotlinx.android.synthetic.main.card_country.view.*

class CountryViewAdapter (val context: Context) : RecyclerView.Adapter<CountryViewAdapter.ViewHolder>() {

    private val layoutInflater: LayoutInflater = context
        .getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    val asyncListDiffer = AsyncListDiffer(this,
    CountryDiffUtilCallback())

    fun setData(newItems: List<CountryModel>){
        asyncListDiffer.submitList(newItems)
    }


    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view){

        private val name_txt =view.name_txt
        private val nativeName_txt =view.nativeName_txt
        private val area_txt =view.area_txt
        private val card_main_lil =view.card_main_lil

        fun bind(countryModel :CountryModel){

            name_txt.text = countryModel.name
            nativeName_txt.text = countryModel.nativeName
            area_txt.text = countryModel.area

            card_main_lil.setOnTouchListener(object : View.OnTouchListener {
                override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                    when (event?.action) {

                        MotionEvent.ACTION_DOWN -> {

                            name_txt.setTextColor(Color.WHITE)
                            nativeName_txt.setTextColor(Color.WHITE)
                            area_txt.setTextColor(Color.WHITE)
                        }

                        MotionEvent.ACTION_MOVE -> { }

                        MotionEvent.ACTION_UP -> {

                            name_txt.setTextColor(Color.BLACK)
                            nativeName_txt.setTextColor(Color.BLACK)
                            area_txt.setTextColor(Color.BLACK)

                            context.startActivity(Intent(context,CountryActivity::class.java).putExtra("alpha3Code",countryModel.alpha3Code))
                        }

                        MotionEvent.ACTION_CANCEL -> {

                            name_txt.setTextColor(Color.BLACK)
                            nativeName_txt.setTextColor(Color.BLACK)
                            area_txt.setTextColor(Color.BLACK)

                        }

                    }

                    return true
                }
            })

            card_main_lil.setOnClickListener {
                context.startActivity(Intent(context,CountryActivity::class.java).putExtra("alpha3Code",countryModel.alpha3Code))
            }
        }

    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val view = layoutInflater.inflate(R.layout.card_country, parent, false)
        return ViewHolder(view)

    }

    override fun getItemCount(): Int {
       return asyncListDiffer.currentList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        holder.bind(asyncListDiffer.currentList[position])
    }



}




